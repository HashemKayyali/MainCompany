import { useTheme } from '../../contexts/ThemeContext'
import { type InputHTMLAttributes } from 'react'
export default function Input({ label, error, className = '', id, ...props }: InputHTMLAttributes<HTMLInputElement> & { label?: string; error?: string }) {
  const { isDark } = useTheme()
  return <div>{label && <label htmlFor={id} className={`block text-[13px] mb-2 font-medium ${isDark ? 'text-purple-200/80' : 'text-gray-600'}`}>{label}</label>}<input id={id} className={`form-field ${error ? isDark ? '!border-red-400/40' : '!border-red-300' : ''} ${className}`} {...props} />{error && <p className="text-red-400 text-xs mt-1.5">{error}</p>}</div>
}
