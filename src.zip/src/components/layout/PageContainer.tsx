import { type ReactNode } from 'react'
import { useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import Navbar from './Navbar'
import Footer from './Footer'
import AnimatedBackground from '../theme/AnimatedBackground'
import { useSmoothScroll } from '../../hooks/useSmoothScroll'

export default function PageContainer({ children }: { children: ReactNode }) {
  const { pathname } = useLocation()
  useSmoothScroll()

  return (
    <div className="relative flex min-h-screen flex-col overflow-x-clip">
      {/* Skip to content — visible on focus for keyboard users */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[100] focus:px-4 focus:py-2 focus:rounded-xl focus:bg-purple-600 focus:text-white focus:text-sm focus:font-semibold focus:shadow-lg"
      >
        Skip to content
      </a>

      <AnimatedBackground position="absolute" className="z-0 overflow-x-clip" />

      <div
        className="relative z-10 flex min-h-screen min-w-0 flex-col overflow-x-clip"
        style={{ ['--app-header-offset' as const]: 'var(--app-navbar-height)' }}
      >
        <Navbar />
        <motion.main
          id="main-content"
          key={pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="flex-1 min-w-0 overflow-visible"
          style={{ paddingTop: 'var(--app-header-offset)' }}
        >
          {children}
        </motion.main>
        <Footer />
      </div>
    </div>
  )
}
