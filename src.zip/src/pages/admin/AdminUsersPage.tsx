import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth, type AdminRole } from '../../contexts/AuthContext'
import { useTheme } from '../../contexts/ThemeContext'
import { useToast } from '../../contexts/ToastContext'
import { useDialog } from '../../contexts/DialogContext'
import Modal from '../../components/ui/Modal'

interface UserProfile {
  id: string
  email: string
  name: string
  phone: string
  role: string
  created_at: string
}

export default function AdminUsersPage() {
  const { isSuperAdmin, changeAdminRole } = useAuth()
  const { isDark } = useTheme()
  const { toast } = useToast()
  const dialog = useDialog()

  const [users, setUsers] = useState<UserProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  // Edit modal
  const [editUser, setEditUser] = useState<UserProfile | null>(null)
  const [editName, setEditName] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editRole, setEditRole] = useState('')
  const [editSaving, setEditSaving] = useState(false)

  const txt = isDark ? 'text-white' : 'text-gray-900'
  const sub = isDark ? 'text-purple-200/80' : 'text-gray-500'

  // ── Fetch all users ──
  const fetchUsers = useCallback(async () => {
    try {
      const { data, error } = await supabase.rpc('get_all_users') as any
      if (error) throw error
      setUsers((data || []).map((u: any) => ({
        id: u.id,
        email: u.email || '',
        name: u.name || '',
        phone: u.phone || '',
        role: u.role || 'user',
        created_at: u.created_at || '',
      })))
    } catch (err) {
      console.error('Failed to fetch users:', err)
      toast('Failed to load users', 'error')
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => { fetchUsers() }, [fetchUsers])

  // ── Filtered users ──
  const filtered = search.trim()
    ? users.filter(u =>
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase()) ||
        u.phone.includes(search)
      )
    : users

  // ── Open edit modal ──
  const openEdit = (u: UserProfile) => {
    setEditUser(u)
    setEditName(u.name)
    setEditPhone(u.phone)
    setEditRole(u.role)
  }

  // ── Save name/phone ──
  const handleSave = async () => {
    if (!editUser) return
    setEditSaving(true)
    try {
      const { data, error } = await supabase.rpc('admin_update_user', {
        target_id: editUser.id,
        new_name: editName.trim() || null,
        new_phone: editPhone.trim() || null,
      }) as any

      if (error) throw error
      if (data && !data.ok) {
        toast(data.error || 'Failed to update', 'error')
        return
      }

      toast(`${editName || editUser.email} updated`, 'success')
      await fetchUsers()
      setEditUser(null)
    } catch (err: any) {
      toast(err?.message || 'Failed to update user', 'error')
    } finally {
      setEditSaving(false)
    }
  }

  // ── Change role (superadmin only) ──
  const handleRoleChange = async () => {
    if (!editUser || !isSuperAdmin) return
    if (editRole === editUser.role) return

    // Protect superadmins
    if (editUser.role === 'superadmin') {
      toast('Cannot change superadmin role from here', 'error')
      return
    }

    setEditSaving(true)
    try {
      if (editRole === 'user') {
        // Demote: use remove_admin
        const { data, error } = await supabase.rpc('remove_admin', { target_id: editUser.id }) as any
        if (error) throw error
        if (data && !data.ok) { toast(data.error, 'error'); return }
      } else {
        // Promote: use set_admin_role
        const ok = await changeAdminRole(editUser.id, editRole as AdminRole)
        if (!ok) { toast('Failed to change role', 'error'); return }
      }

      toast(`${editUser.name || editUser.email} is now ${editRole}`, 'success')
      await fetchUsers()
      setEditUser(null)
    } catch (err: any) {
      toast(err?.message || 'Failed to change role', 'error')
    } finally {
      setEditSaving(false)
    }
  }

  // ── Reset password ──
  const handleResetPassword = async () => {
    if (!editUser) return
    const ok = await dialog.confirm({
      title: 'Send Password Reset?',
      message: `This will send a password reset email to ${editUser.email}. The user will need to click the link to set a new password.`,
      confirmLabel: 'Send Reset Email',
    })
    if (!ok) return

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(editUser.email, {
        redirectTo: `${window.location.origin}/auth/callback`,
      })
      if (error) throw error
      toast(`Reset email sent to ${editUser.email}`, 'success')
    } catch (err: any) {
      toast(err?.message || 'Failed to send reset email', 'error')
    }
  }

  // ── Role badge ──
  const roleBadge = (role: string) => {
    if (role === 'superadmin') return isDark ? 'bg-amber-400/10 text-amber-300 border-amber-400/20' : 'bg-amber-50 text-amber-600 border-amber-200'
    if (role === 'admin') return isDark ? 'bg-purple-500/10 text-purple-200/90 border-purple-500/25' : 'bg-violet-50 text-violet-600 border-violet-200'
    return isDark ? 'bg-white/5 text-white/50 border-white/10' : 'bg-gray-50 text-gray-400 border-gray-200'
  }

  const avatarColor = (role: string) => {
    if (role === 'superadmin') return 'bg-gradient-to-br from-amber-400 to-orange-500 text-white'
    if (role === 'admin') return 'bg-gradient-to-br from-prism-violet to-prism-cyan text-void-950'
    return isDark ? 'bg-white/10 text-white/70' : 'bg-gray-100 text-gray-500'
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className={`font-display text-2xl font-bold ${txt}`}>Users</h1>
          <p className={`text-sm ${sub}`}>{users.length} registered user{users.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      {/* Search */}
      <div className="mb-5">
        <input
          className="form-field !max-w-sm"
          placeholder="Search by name, email, or phone..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Loading */}
      {loading && (
        <div className={`py-16 text-center text-sm ${sub}`}>
          <div className="animate-spin w-6 h-6 border-2 border-current border-t-transparent rounded-full mx-auto mb-3" />
          Loading users...
        </div>
      )}

      {/* User List */}
      {!loading && (
        <div className="space-y-2">
          {filtered.length === 0 && (
            <div className={`py-12 text-center text-sm ${sub}`}>
              {search ? 'No users match your search.' : 'No users found.'}
            </div>
          )}

          {filtered.map(u => (
            <div key={u.id} className="card-surface rounded-2xl p-4 flex items-center gap-4">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold font-display shrink-0 ${avatarColor(u.role)}`}>
                {(u.name || u.email || '?').charAt(0).toUpperCase()}
              </div>

              <div className="flex-1 min-w-0">
                <div className={`text-sm font-medium truncate ${txt}`}>
                  {u.name || <span className={sub}>No name</span>}
                </div>
                <div className={`text-xs truncate ${sub}`}>{u.email}</div>
              </div>

              {/* Phone */}
              {u.phone && (
                <span className={`hidden sm:block text-xs font-mono ${sub}`}>{u.phone}</span>
              )}

              {/* Role badge */}
              <span className={`px-2 py-0.5 rounded-lg text-[10px] font-mono uppercase tracking-wider border ${roleBadge(u.role)}`}>
                {u.role}
              </span>

              {/* Edit button */}
              <button
                onClick={() => openEdit(u)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                  isDark
                    ? 'border-purple-500/25 text-purple-200/80 hover:bg-purple-500/10'
                    : 'border-violet-200 text-gray-600 hover:bg-violet-50'
                }`}
              >
                Edit
              </button>
            </div>
          ))}
        </div>
      )}

      {/* ── Edit User Modal ── */}
      <Modal open={!!editUser} onClose={() => setEditUser(null)} title={`Edit User`} persistent>
        {editUser && (
          <div className="space-y-5">
            {/* User info header */}
            <div className={`px-4 py-3 rounded-xl flex items-center gap-3 ${isDark ? 'bg-white/[0.03] border border-white/10' : 'bg-gray-50 border border-gray-200'}`}>
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold font-display ${avatarColor(editUser.role)}`}>
                {(editUser.name || editUser.email || '?').charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0">
                <div className={`text-sm font-medium truncate ${txt}`}>{editUser.email}</div>
                <div className={`text-[10px] font-mono ${sub}`}>
                  Joined {new Date(editUser.created_at).toLocaleDateString()}
                </div>
              </div>
              <span className={`ml-auto px-2 py-0.5 rounded-lg text-[10px] font-mono uppercase border ${roleBadge(editUser.role)}`}>
                {editUser.role}
              </span>
            </div>

            {/* Name */}
            <div>
              <label className={`block text-[12px] mb-1.5 font-medium ${sub}`}>Name</label>
              <input className="form-field" value={editName} onChange={e => setEditName(e.target.value)} placeholder="User's name" />
            </div>

            {/* Phone */}
            <div>
              <label className={`block text-[12px] mb-1.5 font-medium ${sub}`}>Phone</label>
              <input className="form-field" type="tel" value={editPhone} onChange={e => setEditPhone(e.target.value)} placeholder="+962..." />
            </div>

            {/* Reset Password */}
            <div>
              <button
                onClick={handleResetPassword}
                className={`w-full px-4 py-2.5 rounded-xl text-xs font-medium border transition-all text-left ${
                  isDark
                    ? 'border-cyan-500/20 text-cyan-300 hover:bg-cyan-500/10'
                    : 'border-blue-200 text-blue-600 hover:bg-blue-50'
                }`}
              >
                📧 Send Password Reset Email
              </button>
            </div>

            {/* Role change — superadmin only */}
            {isSuperAdmin && editUser.role !== 'superadmin' && (
              <div className={`p-4 rounded-xl border ${isDark ? 'border-amber-400/20 bg-amber-400/5' : 'border-amber-200 bg-amber-50/50'}`}>
                <label className={`block text-[12px] mb-1.5 font-medium ${isDark ? 'text-amber-300' : 'text-amber-700'}`}>
                  Change Role (Superadmin only)
                </label>
                <div className="flex gap-2 items-center">
                  <select className="form-field flex-1" value={editRole} onChange={e => setEditRole(e.target.value)}>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                    <option value="superadmin">Super Admin</option>
                  </select>
                  <button
                    onClick={handleRoleChange}
                    disabled={editSaving || editRole === editUser.role}
                    className="btn-primary !px-4 !py-2.5 !rounded-xl !text-xs disabled:opacity-50 shrink-0"
                  >
                    {editSaving ? '⏳' : 'Apply'}
                  </button>
                </div>
              </div>
            )}

            {/* Superadmin protection notice */}
            {editUser.role === 'superadmin' && (
              <div className={`px-4 py-3 rounded-xl text-xs ${isDark ? 'bg-amber-400/10 border border-amber-400/20 text-amber-300' : 'bg-amber-50 border border-amber-200 text-amber-700'}`}>
                🔒 Superadmin role can only be changed from Supabase dashboard.
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3 justify-end mt-4">
              <button onClick={() => setEditUser(null)} className="btn-outline !px-5 !py-2.5 !rounded-xl !text-sm">
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={editSaving || (editName === editUser.name && editPhone === editUser.phone)}
                className="btn-primary !px-6 !py-2.5 !rounded-xl !text-xs disabled:opacity-50"
              >
                {editSaving ? '⏳ Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
